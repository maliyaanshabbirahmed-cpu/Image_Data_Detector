# Image Data Extractor

A Streamlit application that extracts text from images and PDFs with locally installed Tesseract OCR, organizes recognized content into a basic table, and exports CSV and formatted Excel files.

## Features

- Upload one JPG, JPEG, PNG or PDF file (10 MB maximum)
- Capture an image using a supported device camera
- Optional crop/region selection
- Local OCR with no API key or paid API
- English, Urdu and Arabic language choices (subject to installed language packs)
- Image enhancement: denoising, contrast normalization, modest deskew and thresholding
- Recognized-text and structured-data previews
- CSV export and formatted Excel export
- Quality report with token count, confidence estimate, rows, columns and elapsed time
- No permanent extraction-history database

## Run locally

1. Install Python 3.10–3.12.
2. Install Tesseract OCR and language packs. On Debian/Ubuntu:

   ```bash
   sudo apt-get update
   sudo apt-get install tesseract-ocr tesseract-ocr-eng tesseract-ocr-urd tesseract-ocr-ara
   ```

   On Windows, install Tesseract OCR and add its installation folder to PATH.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```
4. Start:

   ```bash
   streamlit run app.py
   ```

## Deploy on Streamlit Community Cloud

1. Upload the project folder contents to a GitHub repository.
2. Create a Streamlit Community Cloud app from the repository.
3. Set the main file path to `app.py`.
4. Streamlit installs Python dependencies from `requirements.txt` and system packages from `packages.txt`.

## Run tests

```bash
python -m unittest -v
```

## Known limitations — read before relying on results

- **Handwriting:** Tesseract is mainly designed for printed text. Handwriting recognition is not reliably supported and cannot be guaranteed.
- **All languages:** No single small deployment supports every language. This project installs English, Urdu and Arabic packs; other languages require adding their Tesseract language packages.
- **PDF:** Only the first page of a PDF is processed.
- **Tables:** Structuring is heuristic. Complex tables, merged cells, layouts and columns may be reconstructed incorrectly.
- **Mathematics:** Formula layout and special mathematical symbols may be misread. This is not a dedicated mathematical OCR engine.
- **Automatic structuring:** The app preserves recognized text but cannot always infer the intended schema.
- **No editing or batch mode:** Per the selected settings, this version processes one file at a time and exports without an in-app editing grid.
- **OCR accuracy:** Confidence scores are estimates, not guarantees. Always verify important names, numbers, dates and financial records against the source.

## Privacy

The application does not create a permanent database or extraction history. Results remain in the active Streamlit session unless cleared. Hosting providers may retain operational logs or temporary data under their own policies.
